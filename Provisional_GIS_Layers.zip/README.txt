PROVISIONAL GIS LAYERS — NOT SURVEY ACCURATE

Geology_PRELIMINARY.tif: 2011 PDF rendered at 72 dpi and registered from its printed grid.
Minerals_PRELIMINARY.tif: 2023 PDF rendered at 72 dpi; embedded measure plus +0.0753 degrees east and +0.0578 degrees north, an exploratory fit to Natural Earth river centrelines.
Both TIFFs carry EPSG:4326 only as a working visualization assumption; neither original datum is established. No verified datum transformation was performed. Overlay is not for exploration, licensing, navigation, surveying or exact location. Read the River Alignment report and original PDF legends.
