# Consolidated Nigeria shapefiles and geospatial outputs

This archive collects the generated vector layers, all shapefile sidecars, supporting QA/georeferencing/source metadata, readmes, and the existing convenience ZIPs from `shapefile_results/` and `shapefiles/`. Paths are kept relative to the repository root.

## Nigeria whole-country reference

`shapefiles/nigeria_admin0/nigeria_admin0.shp` (with its `.shx`, `.dbf`, `.prj`, and `.cpg`) is the complete Nigeria Admin-0 polygon used as the fixed reference for M2 clipping and georeferencing checks. It is included as a reference layer, not as a geology output.

## Included groups

- `shapefile_results/geology/`: Nigeria geology units and legend/QA/georeferencing metadata.
- `shapefile_results/minerals/`: mineral symbol points and supporting metadata.
- `shapefile_results/pdf_selected_layers/`: G1–G5 geology outputs, M2 geology areas, Pegmatite marks, source raster, QA and the M2 accuracy assessment.
- `shapefiles/nigeria_online_layers/`: online Nigeria boundaries, populated places, transport/hydrography layers, source and validation metadata. The `grid3_settlement_names_source/` directory contains scripts/metadata only; no GRID3 feature dataset was obtained.
- `shapefile_results/nigeria_shapefiles.zip`, `shapefile_results/nigeria_pdf_selected_layers.zip`, and `shapefiles/nigeria_online_layers.zip` are also included as the original convenience bundles, in addition to the directly browsable files.

Most output layers declare EPSG:4326 in their `.prj` sidecars; check each layer's metadata for source and method notes.

`SHA256SUMS.txt` lists checksums for every other file in this archive.
