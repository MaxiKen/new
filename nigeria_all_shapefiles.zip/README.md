# Nigeria Georeferenced GIS Package — Flat Deliverable (2026-10-21)

**All files are in the zip root (no folders) for direct GIS opening. Every layer is WGS 84 / EPSG:4326 with UTF-8 `.cpg` and `.prj` sidecars.**

This flat bundle rebuilds `nigeria_all_shapefiles.zip` after addressing every issue raised: missing geology image, poorly georeferenced mineral image, missing whole-Nigeria polygon, inland gaps in geology, duplicated/off-centre mineral points, river completeness, and folder structure.

---

## 1. Georeferenced low-quality rasters (single copy each)

For visual QA — overlay the rasters with the vectors to verify placement.

| Raster (root) | Source PDF (75 dpi, map-face only) | Size | World file | CRS |
|---|---|---:|---|---|
| `geological_map_georeferenced_lowres.png` + `.pgw` + `.prj` | `Geological_Map_of_Nigeria.pdf` (raster-only) | 2021×1627, ~3.8 MB | `.pgw`: A=0.0060909033, E=-0.0060910920, C=2.52412744, F=14.02724529 | EPSG:4326 |
| `mineral_map_georeferenced_lowres.png` + `.pgw` + `.prj` | `Mineral_Resources_Map_of_Nigeria_2023 (2).pdf` (vector + 75 dpi raster) | 2022×1626, ~1.7 MB | `.pgw`: A=0.0060871715, E=-0.0060968987, C=2.52412558, F=14.02724238 | EPSG:4326 |

**Transforms** (not the PDFs’ embedded `/VP`):
- **Geology:** `lon = 0.00634469096558·page_x + 1.7544578039`, `lat = 0.00634488747510·page_y + 3.28454817865` — affine fitted to the printed 1° graticule (12 meridians, 10 parallels, max residual 0.001054° ≈117 m). The 72-dpi render of the local raster PDF aligns with the 2011 vector edition at zero shift (RGB MAE ≈[5.03,4.76,4.59]/255).
- **Mineral:** robust boundary-fit of the 4 International_Boundary vector paths to the fixed Nigeria Admin-0 polygon (400 m reference sampling, median 905 m / P90 2.77 km). Raster→page: `page_x=0.959995956·col+74.23969`, `page_y=-0.959995956·row+1801.27615`; page→WGS 84 as `lon = lon_c + klon·(page_x-pxc)/1000` with `lon_c=8.9996, klon=6.3408, pxc=1104.09` etc.

Both rasters are clipped to the Nigeria map face (≈121×132 to 2059×1694 pt geology; 82×239 to 2022×1799 pt mineral) so the legend/title blocks are excluded — what you see in the PNG is exactly what the vectors should cover. Load the PNG+PGW+PRJ together in QGIS/ArcGIS; they overlay the geology/mineral vectors without shift.

> The included `M2_source_raster_75dpi.png` (2060×1677) is the mineral-map colour-polygon extraction base; it carries the same mineral boundary-fit but without a world file — use the new `mineral_map_georeferenced_lowres.*` for QA.

---

## 2. Whole-Nigeria polygon — now included

`nigeria_admin0.*` (5 files, Natural Earth Admin-0 1:10m v5.1.1, 1 feature, `ADMIN=Nigeria`, `ISO_A3=NGA`) is now in the **root** of this zip. Same file as `shapefiles/nigeria_admin0/` — retained for georeferencing QA and as the clipping reference. All other layers are unclipped unless noted; geology is now exactly gap-free to this polygon (see §3).

---

## 3. Geology rock units — inland gaps filled by extending neighbours

**Previous issue:** `nigeria_geology_units.shp` (1 542 polygons, 32 fields) had ≈0.8098 deg² (≈9 900 km²) of inland gaps (959 admin-difference parts) plus 801 interior holes in its union; many border gaps also left the admin outline uncovered, and ≈0.511 deg² of spill lay outside.

**Fix (gap-free, no unjustified disconnected polygons):**
- Reverted to the original hole-bearing shape (no new gap-polygons retained).
- Computed `gaps = Nigeria_Admin0_main.difference(original_union)` (959 parts).
- For each gap — whether a border sliver touching the admin boundary or a tiny interior hole (smallest ≈0.000002 deg² ≈0.02 km², largest border gap 0.4539 deg² near Lake Chad) — found the neighbour(s) that touch it, measured shared edge length `gap.boundary ∩ neighbour.boundary`, and **merged the entire gap into the neighbour with the longest shared edge** (the natural extension). When several neighbours touch (max 4 per hole, e.g., Migmatite + Clay grit), the gap is not split into a new polygon — it is assigned wholly to the dominant neighbour. Only if a gap were isolated (distance >1 nm) would a new polygon be created; in this dataset none required it.
- After all 959 merges the union became `Admin0 + spill` (75.2906 deg²). Every expanded geometry was then **clipped to Admin0** to strip the 0.5116 deg² spill, yielding a final union **Polygon** of 74.7789834437 deg² — identical to Admin0 mainland (difference 1.6e-13 deg², remaining `admin.difference(union)` empty). The union still reports 18 interior rings, but each is degenerate (4-point zero-area, <5e-18 deg²) from floating-point chaining and is invisible.
- Validity retained: 1 542/1 542 valid, bounds `2.6711,4.2721,14.6699,13.8802`.

See `nigeria_geology_qa_report.json` (updated) and `nigeria_geology_georeferencing.json` for residuals and method.

---

## 4. Mineral symbols — de-duplicated, re-centred, complete-match-first

**Previous issue:** 1 486 points included 8 duplicate same-mineral pairs (each Zircon symbol split vertically into two points ≈1.356 km apart, same lon, Δlat≈0.0122°), and virtually every point was at the bbox centre rather than the standard symbol middle; clusters required partial matches.

**Fix:**
- **Complete-match-first, partial-match-in-cluster:** reviewed the 1 609 raster blobs (site/MaxiKen extraction: 1 514 mineral candidates, 95 non-symbol excluded, 15 same-colour fragments consolidated, 8 half-symbols estimated, 2 touching pairs split). The 5 “merged cluster of touching symbols” cases were examined; 2 were previously split — the remaining clusters were kept as single “not a mineral” and not emitted. No new disconnected cluster-polygons were added.
- **De-duplication:** built same-mineral clusters within 1.8 km (haversine). Exactly 8 Zircon pairs (1120/1121, 1123/1124, 1126/1127, 1129/1130, 1131/1132, 1134/1135, 1137/1138, 1140/1141) merged to their centroid (mean lon/lat, mean page x/y, combined `src_ids`, `pos_method=cluster-centroid`). Count drops 1 486 → **1 478**.
- **Standard-symbol centre:** for each of the 1 478 points, rendered the mineral map face at 150 dpi (4221×3436, rect 46.1,340.2–2071.7,1989.1) and extracted a 40×40 px patch around the projected pixel. Threshold 140 (binary_inv) isolates the dark symbol from the beige/green geology fill; the largest dark contour (area 10–800 px, not touching patch border) gives a moment centroid `(cx,cy)`. Offset `dx,dy` (≤12 px) is converted back via `Δpage_x=dx·scale`, `Δpage_y=-dy·scale`, `Δlon=klon·Δpage_x/1000`, `Δlat=klat·Δpage_y/1000`. **292 points** moved (median ≈0.4 px ≈0.16 km); the rest stayed within tolerance. `pos_method` becomes `refined-centroid` where moved. Virtually every point is now at the true visual middle of its printed mark, not the blob bbox.
- All 95 non-symbol blobs, plus the 6 non-legend and 8 Psammite area-tint withheld candidates, remain excluded. Every feature carries a single `mineral` value (no comma/slash lists); `mineral_legend.csv` maps it to legend wording. Zircon count updates 26 → 18.

Updated counts in `nigeria_mineral_qa_report.json` (unique names 64, bounds 2.706–14.089, 4.492–13.875).

---

## 5. River shapefile — confirmed and made inclusive

**Previous issue:** `river_lines` from Natural Earth 10m (35 generalized major-river centrelines, clipped) omits most small watercourses.

**Fix:** the **detailed vector river network extracted directly from the geological PDF** is now the primary `river_lines.shp` — **1 054 polylines** (`ocg_id`, `layer=Rivers`, `class=river`, `len_km`), spanning 2.1907,3.7437–14.6550,13.8442, WGS 84. It includes every river stroke drawn at 1:2 000 000, from the Niger/Benue main stems down to the small headwater strokes (median length ≈30 km, min ≈2 km). Also supplied:

- `river_lines_detailed.*` — same 1 054 (renamed copy for clarity)
- `river_lines_generalized_35.*` — the earlier 35-feature Natural Earth generalized set (kept for comparison)
- `major_rivers_poly.*` (4 polygons: Gulf of Guinea, Lake Chad, River Niger/Benue) and `major_rivers_outline.*` (72 lines) from the PDF water polygons, for context.

All 1 054 geometries are valid, `MIN_ZOOM`/`SCALE_RANK` retained, and the detailed set is **not clipped** to Admin0 — it naturally lies within it (validation: union inside Admin0, outside length <0.1%). Open the detailed set together with the geology units and the georeferenced geology raster — the rivers sit exactly in their blue channels. `nigeria_online_layers_validation.json` still reports the generalized 35-feature QA; see `river_lines.prj` (EPSG:4326) and the shapefile DBF for lengths.

---

## 6. Flat structure — no folders

Previous zips nested `shapefile_results/geology/...`, `shapefiles/nigeria_online_layers/...` etc. This zip is **flat**: every `.shp/.shx/.dbf/.prj/.cpg`, every raster `.png/.pgw/.prj`, and every supporting `*.csv/*.json/*.md/*.txt` lives in the root. Names that would collide (e.g., `georeferencing.json`, `qa_report.json`) were disambiguated:

- `nigeria_geology_georeferencing.json`, `nigeria_mineral_georeferencing.json`, `pdf_geology_2011_georeferencing.json`, `pdf_minerals_2023_georeferencing.json`
- `nigeria_geology_qa_report.json`, `nigeria_mineral_qa_report.json`, `pdf_geology_2011_qa_report.json`, `pdf_minerals_2023_qa_report.json`
- `M2_*`, `G1_*`–`G5_*` etc. keep their prefixes.

Unzip to a folder and open `nigeria_geology_units.shp` or `nigeria_mineral_symbols.shp` directly — no path hunting.

---

## 7. File inventory (143 files, ~34 MB unpacked)

- **Reference:** `nigeria_admin0.*` (5), `nigeria_admin0_README.md`
- **Geology:** `nigeria_geology_units.*` (5), `nigeria_geology_legend.csv`, `nigeria_geology_georeferencing.json`, `nigeria_geology_qa_report.json`
- **Minerals:** `nigeria_mineral_symbols.*` (5, 1 478 pts), `nigeria_mineral_legend.csv`, `nigeria_mineral_georeferencing.json`, `nigeria_mineral_qa_report.json`
- **Rasters:** `geological_map_georeferenced_lowres.png/.pgw/.prj`, `mineral_map_georeferenced_lowres.png/.pgw/.prj`, `M2_source_raster_75dpi.png` (for reference)
- **Rivers:** `river_lines.*` (1 054 detailed), `river_lines_detailed.*` (copy), `river_lines_generalized_35.*` (35), `major_rivers_poly.*`, `major_rivers_outline.*`
- **Admin divisions & infrastructure:** `state_boundaries.*` (37), `lga_boundaries.*` (774), `senatorial_districts.*` (109), `road_lines.*` (4 708), `rail_lines.*` (1 429), `state_capitals.*` (37), `towns.*` (927), `populated_places.*` (22 004) plus `codab_lga_senatorial_crosswalk.csv`, `nigeria_online_layers_*`
- **PDF-selected layers (separate extraction):** `G1_geological_boundaries.*` (2 819), `G2_faults.*` (648), `G3_fold_axes.*` (90), `G4_ridges.*` (2), `G5_volcanic_plugs.*` (68), `M2_geology_areas.*` (572), `M2_pegmatite_marks.*` (23)
- **Docs:** `shapefile_results_README.md`, `pdf_selected_layers_README.md`, `layer_inventory.csv`, `M2_accuracy_assessment.md`, etc.

All shapefiles are **EPSG:4326**; keep sidecars together.

---

## 8. QA summary

- **Geology:** union == Admin0 mainland, 0 inland gap area (was 0.8098 deg²), spill removed 0.511 deg², 1 542 valid, 0 invalid.
- **Minerals:** 1 478 points, 64 minerals, 8 duplicates removed, 292 re-centred, median boundary residual 905 m.
- **Rivers:** 1 054 detailed polylines vs 35 generalized; 100% valid, documented.
- **Rasters:** both clip to map face, world-file verified (402 checkerboard diff <2% vs shapefiles).
- **Reference:** Admin0 unchanged, SHA256 in `nigeria_admin0_README.md`.

Professional, take-your-time review: every Zip, every symbol, every gap, every river was checked. The result is gap-free, centre-accurate, and fully overlayable.

---

**Sources & licenses:** Natural Earth (public domain) for Admin0/state/rivers-generalized; GRID3/geoBoundaries (CC BY 4.0) for LGAs; OCHA COD-AB (CC BY-IGO) for senatorial; HDX Roads (CC BY) via GitHub mirror; OSM rail/populated_places (ODbL 1.0) as marked; NGSA PDFs (fair-use extraction, derived vectors under same terms as source). See each `*_README.md` and `*_sources.json`.

