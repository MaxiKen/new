# Nigeria Geospatial Master Bundle (Root Package)

All files in this zip archive are placed strictly at the ROOT level (no nested subfolders), as requested.

## 1. Georeferenced Map Images & World Files
- `geology_map_georeferenced_50dpi.jpg`, `.jgw`, `.wld`, `.prj`: Low-resolution georeferenced raster of the Geological Map of Nigeria (WGS84 EPSG:4326), aligned to the printed 1-degree graticule controls.
- `mineral_map_georeferenced_50dpi.jpg`, `.jgw`, `.wld`, `.prj`: Low-resolution georeferenced raster of the 2023 Mineral Resources Map of Nigeria (WGS84 EPSG:4326), registered to the national boundary and map extent.

## 2. Whole Country Nigeria Shapefile
- `nigeria_country_boundary.*` / `nigeria_admin0.*`: Complete country-level boundary polygon of Nigeria (WGS84 EPSG:4326).

## 3. Geology Rock Polygons (All Inland Gaps Filled)
- `nigeria_geology_units.*`: 1,542 rock unit polygons covering Nigeria. All 789 inland gaps/holes have been completely filled and merged into the surrounding unit polygons sharing the greatest perimeter boundary, ensuring zero internal gaps without creating disconnected artificial polygons.
- `geology_legend.csv`: Comprehensive legend lookup table matching the geological formation codes and descriptions.

## 4. Mineral Symbol Locations (Precisely Centered & Referenced)
- `nigeria_mineral_symbols.*`: 1,486 mineral point symbols across Nigeria. Point coordinates have been refined to the exact mathematical center of each mapped symbol mark on the map raster (averaging sub-pixel precision), eliminating double-points on single symbols and ensuring clean 1:1 symbol placement.
- `mineral_legend.csv`: Full attribute mapping of mineral commodities, categories, and map legend IDs.

## 5. Comprehensive Rivers & Hydrography Shapefile
- `river_lines.*`: Detailed vector hydrography containing 831 river, stream, and tributary segments extracted from the high-resolution map vector linework. Includes major named rivers (Niger, Benue, Kaduna, Gongola, Sokoto, Hadejia, etc.) as well as all minor streams and tributaries documented with lengths.

## 6. Supporting Baseline Shapefiles
- `state_boundaries.*`, `state_capitals.*`, `lga_boundaries.*`, `towns.*`, `road_lines.*`, `rail_lines.*`.
- Geological structural layers: `G1_geological_boundaries.*`, `G2_faults.*`, `G3_fold_axes.*`, `G4_ridges.*`, `G5_volcanic_plugs.*`, `M2_geology_areas.*`, `M2_pegmatite_marks.*`.
