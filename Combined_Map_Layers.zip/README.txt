COMBINED MAP LAYERS - READ THIS FIRST

What each file is
  Geology_ALIGNED.tif    2011 geological sheet, rendered at 72 dpi, placed by its printed graticule.
  Minerals_ALIGNED.tif   2023 mineral sheet, placed by its embedded GeoPDF /Measure.
  Minerals_Symbol_Points_CORRECTED.geojson / .csv  1,323 printed mineral symbols, coordinates
                         rewritten from the printed graticule into the embedded frame (+18.5 to
                         +19.1 km east). Fields lon_printed / lat_printed keep the old values,
                         lon_was / lat_was the previously published ones.
  Nigeria_Natural_Earth_outline.geojson, Niger_Benue_Natural_Earth.geojson   reference geometry.

Which coordinates to trust
  The mineral sheet printed two coordinate definitions that disagree by 0.172 deg of longitude
  (about 19 km). Its own vector international boundary settles which one the artwork was drawn
  in: 1.06 km median offset from the Natural Earth Nigeria border in the embedded frame versus
  12.94 km in the printed frame. The stored mineral point coordinates had been computed from the
  printed graticule, so they were 19 km too far west; that is what this correction fixes.
  An earlier river-based shift of +0.0753 deg east / +0.0578 deg north is withdrawn (see report).

What this is NOT
  Not a datum transformation and not survey-accurate. Both sheets carry no established datum;
  EPSG:4326 is assigned only so GIS software will display the rasters on a world basemap.
  Do not use for licensing, exploration decisions, navigation or legal boundaries, and do not
  read geology or commodity classes from the blended raster - use the original PDFs.
